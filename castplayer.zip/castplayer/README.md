# CastPlayer
## Build APK without installing anything (GitHub)
1. Create a new GitHub repo, upload all files of this folder (keep .github folder).
2. Open Actions > Build APK > Run workflow.
3. When finished, download "castplayer-apk" from Artifacts, unzip, install app-release.apk.

## Build locally
flutter create --platforms=android --org com.castplayer --project-name castplayer .
(keep lib/ and pubspec.yaml), add to AndroidManifest.xml before <application>:
INTERNET, ACCESS_WIFI_STATE, CHANGE_WIFI_MULTICAST_STATE and android:usesCleartextTraffic="true" on <application>.
flutter build apk --release

## Built-in browser
Search icon in the home app bar opens a browser (Google). Play a video inside the page; detected
m3u8/mp4/mpd links appear on the cast button (bottom corner). Tap a link to cast it to the TV.
